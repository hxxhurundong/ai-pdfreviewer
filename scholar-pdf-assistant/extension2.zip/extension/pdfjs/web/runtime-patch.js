// runtime-patch.js
// 作用：在 PDF.js 初始化完成后，把 “本机地址 / 当前 viewer.origin” 
//       加入 HOSTED_VIEWER_ORIGINS 白名单。

document.addEventListener('webviewerloaded', () => {
  try {
    // 1. 取到当前 viewer 页面自己的 origin
    const myOrigin = window.location.origin || 'null'; // file:// 时为 'null'

    // 2. 先尝试从 PDFViewerApplicationOptions（v3.5+ 推荐方式）读取
    const opts = window.PDFViewerApplicationOptions;
    let list = [];

    if (opts?.get) {
      list = opts.get('hostedViewerOrigins') || [];
      if (!list.includes(myOrigin)) list.push(myOrigin);
      opts.set('hostedViewerOrigins', list);
    } else {
      // 老版本（<=2.x / 早期 3.x）直接改全局变量
      list = window.HOSTED_VIEWER_ORIGINS || [];
      if (!list.includes(myOrigin)) list.push(myOrigin);
      window.HOSTED_VIEWER_ORIGINS = list;
    }

    // 日志方便调试，可删
    console.log('[runtime-patch] HOSTED_VIEWER_ORIGINS →', list);
  } catch (e) {
    console.error('[runtime-patch] 补丁失败：', e);
  }
});
