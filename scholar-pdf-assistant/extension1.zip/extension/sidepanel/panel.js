chrome.runtime.onMessage.addListener(({type, explanation}) => {
  if (type !== "EXPLAIN") return;
  const li = document.createElement("li");
  li.textContent = explanation;
  document.getElementById("log").prepend(li);
});
